var express = require('express');
var router = express.Router();
var mysql = require('mysql');

//------------------
// 載入資料庫連結
//------------------
var pool = require('./lib/db.js');



/* GET home page. */
router.get('/', function(req, res) {
	// 取得使用者傳來的參數
	var proNo=req.param("proNo");
	var proName=req.param("proName");
	var supNo=req.param("supNo");
	var typNo=req.param("typNo");
	var price=req.param("price");
	var stockAmt=req.param("stockAmt");
	var orderAmt=req.param("orderAmt");
	var safeAmt=req.param("safeAmt");
	var inventoryDate=req.param("inventoryDate");
		
	// 將更改資料
	pool.query('UPDATE product SET proName=?, supNo=?, typNo=?, price=?, stockAmt=?, orderAmt=?, safeAmt=?, inventoryDate=? where proNo=?', [proName, supNo, typNo, price, stockAmt, orderAmt, safeAmt, inventoryDate, proNo], function(err, rows, fields) {
		if (err){						
			res.render('updateFail', {});     //導向更改失敗頁面
		}else{
			res.render('updateSuccess', {});  //導向更改成功頁面
		}	
    })
});

module.exports = router;
