var express = require('express');
var router = express.Router();
var mysql = require('mysql');

//----------------------
// 引用db.js
//----------------------
var pool = require('./lib/db.js');
var moment = require('moment');


/* GET home page. */
router.get('/', function(req, res, next) {
	var productData;
    var supplierData;
    var proTypeData;

	//取得使用者輸入的產品編號
	var proNo=req.query.proNo.trim();
	

    //------------------	
	// 取出產品資料
	//------------------
    pool.query('SELECT * FROM product WHERE proNo=?', [proNo], function(err, results) {       
        if (results.length==0) {
            res.render('dataNotFound', {});
			return;
        }else{
            productData=results;
		}
		
		//------------------	
		// 取出供應商資料
		//------------------
		pool.query('SELECT * FROM supplier', function(err, results) {       
			if (err) {
				supplierData=[];
			}else{
				supplierData=results;
			}
			   
			//---------------------	   
			// 取出產品型態資料
			//---------------------
			pool.query('SELECT * FROM proType', function(err, results) {
				if (err) {
					proTypeData=[];
				}else{
					proTypeData=results;
				}

				//-----------------------------------------------------   
				// 將產品, 供應商及產品型態資料一起送給輸入新資料表單
				//-----------------------------------------------------
				res.render('productNewDataForm', {moment:moment, productData:productData, supplierData:supplierData, proTypeData:proTypeData});
    	    }); 
		}); 
	});
});
module.exports = router;