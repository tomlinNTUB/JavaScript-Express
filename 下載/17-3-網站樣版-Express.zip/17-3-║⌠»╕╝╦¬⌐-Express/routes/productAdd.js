var express = require('express');
var router = express.Router();
var mysql = require('mysql');

//------------------
// 載入資料庫連結
//------------------
var pool = require('./lib/db.js');

//-----------------
// 引用multer外掛
//----------------- 
var multer  = require('multer');

//---------------------------------
// 宣告上傳存放空間及檔名更改
//---------------------------------
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
	    //檔案存在<public>內的<images>中.
        cb(null, 'public\\images');
    },

    filename: function (req, file, cb) {
	    //將檔名前增加時間標記, 避免圖名重覆而被覆蓋.  
        cb(null, Date.now()+"--"+file.originalname);
		
    }   
})

//-----------------------------------------------
// 產生multer的上傳物件
//-----------------------------------------------
var maxSize=300*1024;  //設定最大可接受圖片大小(300K)

var upload = multer({
    storage:storage
})


/* POST home page. */
router.post('/', upload.single('picture'), function(req, res) {
    // 如果有選擇圖片
    if (typeof req.file != 'undefined'){
        //----------------------------------
        // 傳入檔案不可超過maxSize(300KB) 
        //----------------------------------
        if(req.file.size>maxSize){
            res.render('fileSizeFail', {});  //圖檔超過, 新增失敗
            return;
        }                      
    }      

    // 取得使用者傳來的參數
    var proNo=req.param("proNo");
    var proName=req.param("proName");
    var supNo=req.param("supNo");
    var typNo=req.param("typNo");
    var price=req.param("price");
    var stockAmt=req.param("stockAmt");
    var orderAmt=req.param("orderAmt");
    var safeAmt=req.param("safeAmt");
    var inventoryDate=req.param("inventoryDate");
    var picture='';
	
    // 如果有選擇圖片
    if (typeof req.file != 'undefined'){
        picture=req.file.filename;   //取得上傳照片新名稱             
    }
    
    // 建立一個新資料物件
    var newData={
        proNo:proNo,
        proName:proName,
        supNo:supNo,
        typNo:typNo,
        price:price,
        stockAmt:stockAmt,
        orderAmt:orderAmt,
        safeAmt:safeAmt,
        inventoryDate:inventoryDate,
        picture:picture
    }   

    pool.query('INSERT INTO product SET ?', newData, function(err, rows, fields) {
        if (err){
            res.render('addFail', {});     //新增失敗
        }else{
            res.render('addSuccess', {});  //新增成功
        }
    });
});

module.exports = router;