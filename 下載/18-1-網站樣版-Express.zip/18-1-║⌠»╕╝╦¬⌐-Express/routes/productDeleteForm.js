var express = require('express');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
	//-------------------------
	// 導向刪除畫面
	//-------------------------
	res.render('productDeleteForm', {});  	
});

module.exports = router;