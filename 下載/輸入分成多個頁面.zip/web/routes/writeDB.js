var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  var pw1 = req.params.pw1;
  var pw2 = req.params.pw2;

  //將session中資料取出
  stuno = req.session.stuno;
  name = req.session.name;
  id = req.session.id;

  birthday = req.session.birthday;
  gender = req.session.gender;
  department = req.session.department;

  console.log(stuno);
  console.log(name);
  console.log(id);
  console.log(birthday);
  console.log(gender);
  console.log(department);
  console.log(pw1);
  console.log(pw2);

  //執行某些資料庫動作
  res.render('success');
});

/* POST home page. */
router.post('/', function(req, res, next) {
  var pw1 = req.body.pw1;
  var pw2 = req.body.pw2;

  //將session中資料取出
  stuno = req.session.stuno;
  name = req.session.name;
  stuid = req.session.stuid;

  birthday = req.session.birthday;
  gender = req.session.gender;
  department = req.session.department;

  console.log('----------------------')
  console.log(stuno);
  console.log(name);
  console.log(stuid);
  console.log(birthday);
  console.log(gender);
  console.log(department);
  console.log(pw1);
  console.log(pw2);
  console.log('----------------------')

  //執行某些資料庫動作
  res.render('finish');
});

module.exports = router;
