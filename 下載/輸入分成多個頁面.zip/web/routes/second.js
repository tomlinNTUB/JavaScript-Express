var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  var stuno = req.params.stuno;
  var name = req.params.name;
  var id = req.params.id;

  //將資料加入session中
  req.session.stuno = stuno;
  req.session.name = name;
  req.session.id = id;

  res.render('second');
});

/* POST home page. */
router.post('/', function(req, res, next) {
  var stuno = req.body.stuno;
  var name = req.body.name;
  var stuid = req.body.stuid;

  //將資料加入session中
  req.session.stuno = stuno;
  req.session.name = name;
  req.session.stuid = stuid;

  res.render('second');
});

module.exports = router;
