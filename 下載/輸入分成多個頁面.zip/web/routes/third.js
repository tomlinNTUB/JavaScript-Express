var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  var birthday = req.params.birthday;
  var gender = req.params.gender;
  var department = req.params.department;

  //將資料加入session中
  req.session.birthday = birthday;
  req.session.gender = gender;
  req.session.department = department;

  res.render('third');
});

/* POST home page. */
router.post('/', function(req, res, next) {
  var birthday = req.body.birthday;
  var gender = req.body.gender;
  var department = req.body.department;

  //將資料加入session中
  req.session.birthday = birthday;
  req.session.gender = gender;
  req.session.department = department;

  res.render('third');
});

module.exports = router;
