var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

//---------------------------------------------------------
// 增加以下的require
//---------------------------------------------------------
var loginForm = require('./routes/loginForm');
var login = require('./routes/login');
var loginSuccess = require('./routes/loginSuccess');
var loginFail = require('./routes/loginFail');
var logout = require('./routes/logout');
//---------------------------------------------------------

var app = express();

//-----------------------------------------
// 增加使用session及uuid
//-----------------------------------------
var session=require('express-session');
var uuid=require('uuid');

app.use(session({
    genid:function(req){
        return uuid.v1();
    },
    secret: 'secretcode',
    resave: true,
    saveUninitialized: true
}));
//-----------------------------------------

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


//---------------------------
// 首頁設定為登入畫面
//---------------------------
app.use('/', loginForm);


//--------------------------------------------
// 增加以下的app.use()
//--------------------------------------------
app.use('/loginForm', loginForm);
app.use('/login', login);
app.use('/loginSuccess', loginSuccess);
app.use('/loginFail', loginFail);
app.use('/logout', logout);
//--------------------------------------------

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
